# LabGuard AI — Cursor Starter

A starter desktop application for laboratory safety workflows. It uses PySide6 and SQLite.

## Requirements
- macOS with Python 3.11+ (Python 3.12 is a good choice)
- Cursor editor

## Run locally
Open this folder in Cursor. In Cursor's Terminal, run:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python app/main.py
```

If `python3` is not installed, install Python 3 from python.org first.

## Data
SQLite database is created at:
`~/Library/Application Support/LabGuardAI/labguard.db`

## Important limitations
- This is a starter/MVP, not a validated safety system.
- Sample PPE and training content are reminders, not chemical-specific advice.
- No live AI connection, SDS document retrieval, QR scanning, authentication, role-based access, or audit-grade logging is implemented yet.
- Do not use the application to authorize chemical handling or calculate acid dilutions. Connect approved SDS/SOP documents and have a qualified safety professional validate workflows before operational use.

## Suggested next steps in Cursor
Open `CURSOR_PROMPT.md` and paste its contents into Cursor Chat/Agent.

import sys
import sqlite3
from pathlib import Path
from datetime import date
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QLabel,
    QPushButton, QFrame, QStackedWidget, QLineEdit, QComboBox, QFormLayout,
    QTableWidget, QTableWidgetItem, QMessageBox, QTextEdit, QCheckBox,
    QHeaderView, QSpinBox
)

APP_DIR = Path.home() / "Library" / "Application Support" / "LabGuardAI"
APP_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = APP_DIR / "labguard.db"

TR = {
    "dashboard":"Genel Bakış", "inventory":"Kimyasal Envanteri", "ppe":"KKD Rehberi",
    "inspections":"Haftalık Denetimler", "academy":"Safety Academy", "incidents":"Olay Bildirimi",
    "assistant":"Güvenlik Asistanı", "settings":"Ayarlar", "overview":"Laboratuvar güvenlik özeti",
    "chemicals":"Kimyasal kayıtları", "checks":"Kontrol maddeleri", "reports":"Olay bildirimleri",
    "add":"＋ Kimyasal ekle", "name":"Kimyasal adı", "quantity":"Miktar", "unit":"Birim",
    "location":"Konum / raf", "expiry":"Son kullanma tarihi (YYYY-MM-DD)", "save":"Kaydet",
    "search":"Kimyasal ara…", "status":"Durum", "attention":"Kontrol gerekli",
    "ppe_title":"KKD ve güvenli çalışma", "ppe_note":"KKD seçimi kimyasalın güncel SDS belgesi ve işyeri risk değerlendirmesiyle doğrulanmalıdır.",
    "inspection_title":"Haftalık laboratuvar denetimi", "inspection_note":"Her maddeyi fiziksel olarak kontrol ettikten sonra işaretleyin.",
    "save_check":"Denetimi kaydet", "incident_title":"Olay / ramak kala bildirimi",
    "type":"Olay türü", "description":"Açıklama", "severity":"Önem derecesi",
    "submit":"Bildirimi kaydet", "assistant_note":"Bu başlangıç sürümünde canlı AI bağlantısı yoktur. Onaylı SDS/SOP belgeleri bağlanmadan kimyasal işlem talimatı veya karışım miktarı üretmeyin.",
    "language":"Dil / Language", "empty":"Henüz kayıt yok.", "saved":"Kayıt kaydedildi.",
    "demo":"İlk sürüm · Yerel veritabanı", "low":"Düşük", "medium":"Orta", "high":"Yüksek",
    "spill":"Kimyasal dökülme", "unlabelled":"Etiketsiz kap", "damaged":"Hasarlı kap", "missing":"Eksik KKD", "near":"Ramak kala",
    "goggles":"Kimyasal sıçrama gözlüğü", "gloves":"Kimyasala uygun eldiven", "clothing":"Koruyucu giysi",
    "ventilation":"Uygun havalandırma", "eyewash":"Göz duşu erişilebilir ve kontrol edilmiş",
    "spillkit":"Dökülme kiti mevcut ve uygun", "labels":"Kaplar etiketli ve okunaklı",
    "emergency":"Acil durum ekipmanına erişim açık", "sds":"Güncel SDS ve onaylı prosedür kontrol edildi",
    "training":"Eğitim içerikleri", "lesson":"Etiketleri ve SDS'yi okuma",
}
EN = {
    "dashboard":"Overview", "inventory":"Chemical Inventory", "ppe":"PPE Guide",
    "inspections":"Weekly Inspections", "academy":"Safety Academy", "incidents":"Incident Reports",
    "assistant":"Safety Assistant", "settings":"Settings", "overview":"Laboratory safety overview",
    "chemicals":"Chemical records", "checks":"Checklist items", "reports":"Incident reports",
    "add":"＋ Add chemical", "name":"Chemical name", "quantity":"Quantity", "unit":"Unit",
    "location":"Location / shelf", "expiry":"Expiry date (YYYY-MM-DD)", "save":"Save",
    "search":"Search chemicals…", "status":"Status", "attention":"Needs review",
    "ppe_title":"PPE and safe work", "ppe_note":"Verify PPE selection against the chemical's current SDS and site risk assessment.",
    "inspection_title":"Weekly laboratory inspection", "inspection_note":"Physically verify each item before checking it.",
    "save_check":"Save inspection", "incident_title":"Incident / near-miss report",
    "type":"Incident type", "description":"Description", "severity":"Severity",
    "submit":"Save report", "assistant_note":"This starter has no live AI connection. Do not generate chemical procedure instructions or mixing quantities until approved SDS/SOP documents are connected.",
    "language":"Language", "empty":"No records yet.", "saved":"Record saved.",
    "demo":"Starter · Local database", "low":"Low", "medium":"Medium", "high":"High",
    "spill":"Chemical spill", "unlabelled":"Unlabelled container", "damaged":"Damaged container", "missing":"Missing PPE", "near":"Near miss",
    "goggles":"Chemical splash goggles", "gloves":"Chemically compatible gloves", "clothing":"Protective clothing",
    "ventilation":"Suitable ventilation", "eyewash":"Eyewash accessible and checked",
    "spillkit":"Spill kit present and suitable", "labels":"Containers labelled and legible",
    "emergency":"Emergency equipment access clear", "sds":"Current SDS and approved procedure checked",
    "training":"Learning modules", "lesson":"Reading labels and SDS",
}
CHECKS = ["eyewash", "spillkit", "labels", "ventilation", "emergency", "sds"]

def tr(key, lang):
    return (EN if lang == "en" else TR).get(key, key)

def connect_db():
    con = sqlite3.connect(DB_PATH)
    con.execute("""CREATE TABLE IF NOT EXISTS chemicals(
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, quantity REAL NOT NULL,
        unit TEXT NOT NULL, location TEXT NOT NULL, expiry TEXT DEFAULT '', status TEXT DEFAULT 'Review')""")
    con.execute("""CREATE TABLE IF NOT EXISTS incidents(
        id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, severity TEXT NOT NULL,
        description TEXT NOT NULL, created_at TEXT NOT NULL)""")
    con.execute("""CREATE TABLE IF NOT EXISTS inspections(
        id INTEGER PRIMARY KEY AUTOINCREMENT, item TEXT NOT NULL, checked INTEGER NOT NULL,
        checked_at TEXT NOT NULL)""")
    con.commit()
    return con

class LabGuard(QMainWindow):
    def __init__(self):
        super().__init__()
        self.lang = "tr"
        self.con = connect_db()
        self.setWindowTitle("LabGuard AI")
        self.resize(1200, 780)
        self.setMinimumSize(960, 640)
        self.setStyleSheet("""
            QWidget { background:#F3F7F7; color:#18353A; font-family: -apple-system, BlinkMacSystemFont, 'Helvetica Neue', sans-serif; font-size:13px; }
            QFrame#Sidebar { background:#FFFFFF; border-right:1px solid #DDE8E8; }
            QLabel#Brand { color:#0B5964; font-size:21px; font-weight:800; }
            QLabel#Sub { color:#71868A; font-size:11px; }
            QPushButton { background:#FFFFFF; border:1px solid #DCE7E7; border-radius:8px; padding:10px 13px; text-align:left; }
            QPushButton:hover { border-color:#0B5964; color:#0B5964; }
            QPushButton#Active { background:#E5F0F1; color:#0B5964; border:1px solid #C8E0E2; font-weight:700; }
            QPushButton#Primary { background:#0B5964; color:#FFFFFF; border:0; font-weight:700; }
            QPushButton#Primary:hover { background:#08464F; }
            QLineEdit, QComboBox, QTextEdit, QSpinBox { background:#FFFFFF; border:1px solid #D7E3E4; border-radius:7px; padding:9px; }
            QTableWidget { background:#FFFFFF; border:1px solid #DDE8E8; border-radius:10px; gridline-color:#EAF0F0; }
            QHeaderView::section { background:#EAF2F2; color:#49656A; padding:9px; border:0; font-weight:700; }
            QCheckBox { spacing:10px; padding:9px; }
        """)
        self.pages = QStackedWidget()
        self.page_names = ["dashboard","inventory","ppe","inspections","academy","incidents","assistant"]
        self.nav_buttons = {}
        outer = QWidget(); outer_layout = QHBoxLayout(outer); outer_layout.setContentsMargins(0,0,0,0); outer_layout.setSpacing(0)
        side = QFrame(); side.setObjectName("Sidebar"); side.setFixedWidth(235)
        sl = QVBoxLayout(side); sl.setContentsMargins(17,23,17,18); sl.setSpacing(9)
        brand = QLabel("⬡  LabGuard AI"); brand.setObjectName("Brand")
        sub = QLabel("LABORATORY SAFETY"); sub.setObjectName("Sub")
        sl.addWidget(brand); sl.addWidget(sub); sl.addSpacing(22)
        for key, icon in [("dashboard","▦"),("inventory","⚗"),("ppe","◇"),("inspections","☑"),("academy","▤"),("incidents","⚑"),("assistant","✳")]:
            b=QPushButton(f"{icon}   {tr(key,self.lang)}"); b.clicked.connect(lambda checked=False,k=key:self.navigate(k))
            self.nav_buttons[key]=b; sl.addWidget(b)
        sl.addStretch()
        self.lang_btn=QPushButton("TR  /  EN"); self.lang_btn.clicked.connect(self.toggle_lang); sl.addWidget(self.lang_btn)
        foot=QLabel("●  "+tr("demo",self.lang)); foot.setObjectName("Sub"); sl.addWidget(foot)
        right=QWidget(); rl=QVBoxLayout(right); rl.setContentsMargins(25,21,25,22); rl.setSpacing(15)
        self.breadcrumb=QLabel("LabGuard AI  /  "+tr("dashboard",self.lang)); self.breadcrumb.setStyleSheet("color:#71868A")
        rl.addWidget(self.breadcrumb); rl.addWidget(self.pages,1)
        outer_layout.addWidget(side); outer_layout.addWidget(right,1); self.setCentralWidget(outer)
        self.build_pages(); self.navigate("dashboard")

    def title_label(self, text, size=23):
        x=QLabel(text); x.setStyleSheet(f"font-size:{size}px;font-weight:750;color:#123F46;"); return x
    def card(self):
        f=QFrame(); f.setStyleSheet("QFrame{background:#FFFFFF;border:1px solid #DDE8E8;border-radius:12px;}"); return f
    def build_pages(self):
        # Dashboard
        w=QWidget(); l=QVBoxLayout(w); l.setSpacing(16)
        l.addWidget(self.title_label(tr("overview",self.lang)))
        cards=QHBoxLayout()
        self.stat_labels={}
        for key in ["chemicals","checks","reports"]:
            f=self.card(); fl=QVBoxLayout(f); lab=QLabel(tr(key,self.lang)); lab.setStyleSheet("color:#71868A")
            val=QLabel("0"); val.setStyleSheet("font-size:30px;font-weight:800;color:#0B5964")
            self.stat_labels[key]=val; fl.addWidget(lab); fl.addWidget(val); cards.addWidget(f)
        l.addLayout(cards)
        info=self.card(); il=QVBoxLayout(info); il.addWidget(self.title_label(tr("attention",self.lang),16))
        note=QLabel("•  "+tr("ppe_note",self.lang)+"\n\n•  "+tr("assistant_note",self.lang)); note.setWordWrap(True); note.setStyleSheet("padding:10px;color:#536D72")
        il.addWidget(note); l.addWidget(info); l.addStretch()
        self.pages.addWidget(w); self.dashboard_page=w
        # Inventory
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(self.title_label(tr("inventory",self.lang)))
        form=self.card(); fl=QFormLayout(form); fl.setContentsMargins(15,15,15,15)
        self.c_name=QLineEdit(); self.c_qty=QLineEdit(); self.c_qty.setPlaceholderText("e.g. 1.0")
        self.c_unit=QComboBox(); self.c_unit.addItems(["L","mL","kg","g","pcs"])
        self.c_loc=QLineEdit(); self.c_exp=QLineEdit(); self.c_exp.setPlaceholderText("YYYY-MM-DD")
        fl.addRow(tr("name",self.lang),self.c_name); fl.addRow(tr("quantity",self.lang),self.c_qty)
        fl.addRow(tr("unit",self.lang),self.c_unit); fl.addRow(tr("location",self.lang),self.c_loc); fl.addRow(tr("expiry",self.lang),self.c_exp)
        add=QPushButton(tr("add",self.lang)); add.setObjectName("Primary"); add.clicked.connect(self.add_chemical); fl.addRow(add)
        l.addWidget(form)
        self.search=QLineEdit(); self.search.setPlaceholderText(tr("search",self.lang)); self.search.textChanged.connect(self.refresh_chemicals); l.addWidget(self.search)
        self.chem_table=QTableWidget(0,5); self.chem_table.setHorizontalHeaderLabels([tr("name",self.lang),tr("quantity",self.lang),tr("unit",self.lang),tr("location",self.lang),tr("status",self.lang)])
        self.chem_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); l.addWidget(self.chem_table,1)
        self.pages.addWidget(w); self.inventory_page=w
        # PPE
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(self.title_label(tr("ppe_title",self.lang)))
        note=QLabel(tr("ppe_note",self.lang)); note.setWordWrap(True); note.setStyleSheet("background:#FFF3D9;color:#79520A;padding:13px;border-radius:8px"); l.addWidget(note)
        for key in ["goggles","gloves","clothing","ventilation","sds"]:
            label=QLabel("◇   "+tr(key,self.lang)); label.setStyleSheet("background:#FFFFFF;border:1px solid #DDE8E8;border-radius:8px;padding:15px")
            l.addWidget(label)
        l.addStretch(); self.pages.addWidget(w); self.ppe_page=w
        # Inspection
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(self.title_label(tr("inspection_title",self.lang)))
        note=QLabel(tr("inspection_note",self.lang)); note.setWordWrap(True); note.setStyleSheet("color:#71868A"); l.addWidget(note)
        self.checkboxes=[]
        for key in CHECKS:
            cb=QCheckBox(tr(key,self.lang)); cb.setStyleSheet("background:#FFFFFF;border:1px solid #DDE8E8;border-radius:8px;padding:10px")
            self.checkboxes.append((key,cb)); l.addWidget(cb)
        save=QPushButton(tr("save_check",self.lang)); save.setObjectName("Primary"); save.clicked.connect(self.save_inspection); l.addWidget(save); l.addStretch()
        self.pages.addWidget(w); self.inspection_page=w
        # Academy
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(self.title_label(tr("academy",self.lang)))
        for key,desc in [("lesson","Use the current SDS; check hazards, first aid, handling and storage."),("lesson","Confirm compatibility using the site's approved chemical compatibility chart."),("lesson","Follow site emergency procedures; only trained staff respond to spills.")]:
            f=self.card(); fl=QVBoxLayout(f); fl.addWidget(QLabel(tr(key,self.lang))); d=QLabel(desc); d.setWordWrap(True); d.setStyleSheet("color:#71868A;padding:4px"); fl.addWidget(d); l.addWidget(f)
        l.addStretch(); self.pages.addWidget(w); self.academy_page=w
        # Incidents
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(self.title_label(tr("incident_title",self.lang)))
        form=self.card(); fl=QFormLayout(form); fl.setContentsMargins(15,15,15,15)
        self.i_type=QComboBox()
        for key in ["spill","unlabelled","damaged","missing","near"]: self.i_type.addItem(tr(key,self.lang),key)
        self.i_severity=QComboBox()
        for key in ["low","medium","high"]: self.i_severity.addItem(tr(key,self.lang),key)
        self.i_desc=QTextEdit(); self.i_desc.setMaximumHeight(100)
        fl.addRow(tr("type",self.lang),self.i_type); fl.addRow(tr("severity",self.lang),self.i_severity); fl.addRow(tr("description",self.lang),self.i_desc)
        b=QPushButton(tr("submit",self.lang)); b.setObjectName("Primary"); b.clicked.connect(self.add_incident); fl.addRow(b); l.addWidget(form); l.addStretch()
        self.pages.addWidget(w); self.incident_page=w
        # Assistant placeholder
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(self.title_label(tr("assistant",self.lang)))
        note=QLabel(tr("assistant_note",self.lang)); note.setWordWrap(True); note.setStyleSheet("background:#FFF3D9;color:#79520A;padding:15px;border-radius:9px")
        l.addWidget(note); l.addStretch(); self.pages.addWidget(w); self.assistant_page=w

    def navigate(self,key):
        mapping={"dashboard":self.dashboard_page,"inventory":self.inventory_page,"ppe":self.ppe_page,"inspections":self.inspection_page,"academy":self.academy_page,"incidents":self.incident_page,"assistant":self.assistant_page}
        self.pages.setCurrentWidget(mapping[key]); self.breadcrumb.setText("LabGuard AI  /  "+tr(key,self.lang))
        for k,b in self.nav_buttons.items():
            b.setObjectName("Active" if k==key else "")
            b.setStyleSheet("QPushButton{background:#E5F0F1;color:#0B5964;border:1px solid #C8E0E2;border-radius:8px;padding:10px 9px;font-weight:700}" if k==key else "")
        self.refresh_stats()
        if key=="inventory": self.refresh_chemicals()

    def refresh_stats(self):
        self.stat_labels["chemicals"].setText(str(self.con.execute("SELECT COUNT(*) FROM chemicals").fetchone()[0]))
        self.stat_labels["checks"].setText(str(len(CHECKS)))
        self.stat_labels["reports"].setText(str(self.con.execute("SELECT COUNT(*) FROM incidents").fetchone()[0]))

    def add_chemical(self):
        name=self.c_name.text().strip(); loc=self.c_loc.text().strip()
        try: qty=float(self.c_qty.text())
        except ValueError:
            QMessageBox.warning(self,tr("inventory",self.lang),"Enter a valid numeric quantity."); return
        if not name or not loc or qty<0:
            QMessageBox.warning(self,tr("inventory",self.lang),"Please enter a name, non-negative quantity and location."); return
        expiry=self.c_exp.text().strip()
        if expiry and len(expiry)!=10:
            QMessageBox.warning(self,tr("inventory",self.lang),"Use YYYY-MM-DD for the date."); return
        status="Review"
        if expiry and expiry < date.today().isoformat(): status="Expired"
        self.con.execute("INSERT INTO chemicals(name,quantity,unit,location,expiry,status) VALUES(?,?,?,?,?,?)",
                         (name,qty,self.c_unit.currentText(),loc,expiry,status)); self.con.commit()
        self.c_name.clear(); self.c_qty.clear(); self.c_loc.clear(); self.c_exp.clear()
        self.refresh_chemicals(); self.refresh_stats(); QMessageBox.information(self,tr("inventory",self.lang),tr("saved",self.lang))

    def refresh_chemicals(self):
        if not hasattr(self,"chem_table"): return
        q=self.search.text().lower() if hasattr(self,"search") else ""
        rows=self.con.execute("SELECT name,quantity,unit,location,status FROM chemicals WHERE lower(name) LIKE ? OR lower(location) LIKE ? ORDER BY id DESC",(f"%{q}%",f"%{q}%")).fetchall()
        self.chem_table.setRowCount(len(rows))
        for r,row in enumerate(rows):
            for c,value in enumerate(row): self.chem_table.setItem(r,c,QTableWidgetItem(str(value)))

    def save_inspection(self):
        stamp=date.today().isoformat()
        self.con.execute("DELETE FROM inspections WHERE checked_at=?",(stamp,))
        for key,cb in self.checkboxes:
            self.con.execute("INSERT INTO inspections(item,checked,checked_at) VALUES(?,?,?)",(key,int(cb.isChecked()),stamp))
        self.con.commit(); QMessageBox.information(self,tr("inspections",self.lang),tr("saved",self.lang))

    def add_incident(self):
        desc=self.i_desc.toPlainText().strip()
        if not desc:
            QMessageBox.warning(self,tr("incidents",self.lang),"Please add a description."); return
        self.con.execute("INSERT INTO incidents(kind,severity,description,created_at) VALUES(?,?,?,?)",
                         (self.i_type.currentData(),self.i_severity.currentData(),desc,date.today().isoformat()))
        self.con.commit(); self.i_desc.clear(); self.refresh_stats()
        QMessageBox.information(self,tr("incidents",self.lang),tr("saved",self.lang))

    def toggle_lang(self):
        self.lang="en" if self.lang=="tr" else "tr"
        QMessageBox.information(self,"LabGuard AI","Language changed for navigation and main headings. For full localization, continue implementation in Cursor.")
        # Full dynamic retranslation is delegated to the next implementation step.
        for key,b in self.nav_buttons.items(): b.setText({"dashboard":"▦","inventory":"⚗","ppe":"◇","inspections":"☑","academy":"▤","incidents":"⚑","assistant":"✳"}[key]+"   "+tr(key,self.lang))
        self.breadcrumb.setText("LabGuard AI  /  "+tr(self.page_names[self.pages.currentIndex()],self.lang))

def main():
    app=QApplication(sys.argv)
    app.setApplicationName("LabGuard AI")
    win=LabGuard(); win.show()
    sys.exit(app.exec())

if __name__=="__main__":
    main()
